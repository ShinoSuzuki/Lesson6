# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '0cd6cf364c81d5e9c248fb3e4c74fe989163778d358d635839741170b5a2f892aaf46e20ab8c8cae5f81d2ecbc250ef0d86c74081fb86f5f8d06bac1f1886351'